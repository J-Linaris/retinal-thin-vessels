"""
File with the only purpose of compiling the
'dse_helper' cython file
"""

from setuptools import setup, Extension
from Cython.Build import cythonize
import numpy

extensions = [
    Extension(
        name="retinal_thin_vessels.external.DSE_skeleton_pruning.dsepruning.dse_helper",
        
        sources=["retinal_thin_vessels/external/DSE_skeleton_pruning/dsepruning/dse_helper.c"], 
        
        include_dirs=[numpy.get_include()]
    )
]

setup(
    ext_modules=cythonize(extensions)
)